#include <bits/stdc++.h>
using namespace std;

signed main(int argc, char* argv[])
{
    mt19937_64 rng(atoi(argv[1]));
    
    int tests = rng() % 10000 + 1;
    cout << tests << endl;
    
    for(int i = 0; i < tests; i++) {
        int a = rng() % 2000000001 - 1000000000;
        int b = rng() % 2000000001 - 1000000000;
        cout << a << " " << b << endl;
    }
    
    return 0;
}
